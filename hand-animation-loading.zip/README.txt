A Pen created at CodePen.io. You can find this one at https://codepen.io/r4ms3s/pen/XJqeKB.

 I really liked that little hand animation so I decided to recreate it in good pure CSS only. No JS was harmed.